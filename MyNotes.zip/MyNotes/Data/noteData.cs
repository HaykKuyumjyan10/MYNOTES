﻿namespace MNotes.Data
{
    
    public class noteData
    {
        public int id {  get; set; }
        public string? name { get; set; }
        public string content { get; set; }
        public int? parrentid { get; set; }
    }
}
