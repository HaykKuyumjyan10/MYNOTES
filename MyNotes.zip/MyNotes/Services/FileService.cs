﻿using Microsoft.EntityFrameworkCore;
using MNotes.Data;
using System.Reflection.Metadata;
using System.Threading.Channels;
using TableDependency.SqlClient;
using TableDependency.SqlClient.Base.EventArgs;

namespace MNotes.Services
{
  
    public class FileService : IFileService
    {
        AppDbContext dbContext = new AppDbContext();
        private readonly SqlTableDependency<fileData> _dependency;
        private readonly string _connectionString;

        public FileService()
        {
            _connectionString = "Server = (localdb)\\MSSQLLocalDB;Database = myDataBase; Trusted_Connection = True;";
            _dependency = new SqlTableDependency<fileData>(_connectionString, "fileData");
            _dependency.OnChanged += Changed;
            _dependency.Start();
        }

        private void Changed(object sender, RecordChangedEventArgs<fileData> e)
        {

        }

        public async Task<List<fileData>> GetAllFiles()
        {
            return await dbContext.fileData.AsNoTracking().ToListAsync();
        }
        public async Task AddFile(fileData newFile)
        {
         
           Console.WriteLine(newFile.contentId);
           dbContext.fileData.Add(newFile);
           
           await dbContext.SaveChangesAsync();
        }


        public async Task DeleteFile(int id)
        {
            var fileToDelete = await dbContext.fileData.FindAsync(id);
           
            if (fileToDelete != null )
            {
                
                dbContext.fileData.Remove(fileToDelete);
                await dbContext.SaveChangesAsync();
            }
        }
        public async Task<int> GetLastAddedElementIdAsync()
        {
            int lastAddedId = await dbContext.fileData
                                            .OrderByDescending(f => f.id)
                                            .Select(f => f.id)
                                            .FirstOrDefaultAsync();
            return lastAddedId+1;
        }
        public async Task<int> GetLastAddedNoteElementIdAsync()
        {
            
            int lastAddedId = await dbContext.noteDatas
                                            .OrderByDescending(f => f.id)
                                            .Select(f => f.id)
                                            .FirstOrDefaultAsync();
            return lastAddedId+1;
        }
    }
}
