﻿using MNotes.Data;

namespace MNotes.Services
{
    public interface IFileService
    {
        Task<List<fileData>> GetAllFiles();
        Task AddFile(fileData newFile);
        Task DeleteFile(int id);
        Task<int> GetLastAddedElementIdAsync();
        Task<int> GetLastAddedNoteElementIdAsync();
    }
}
