﻿using MNotes.Data;

namespace MNotes.Services
{
    public interface INoteService
    {
        Task<List<noteData>> GetAllNotes();
        Task AddNote(int parrentId);
        Task DeleteNote(int id);
        Task UpdateNoteContent(int noteId, string content);
        

    }
}
